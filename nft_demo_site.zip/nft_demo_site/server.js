const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const PORT = process.env.PORT || 3000;
const BOT_TOKEN = process.env.BOT_TOKEN;
const CHAT_ID = process.env.CHAT_ID;
const PUBLIC_DIR = path.join(__dirname, "public");

const server = http.createServer(async (req, res) => {
  if (req.method === "POST" && req.url === "/api/send") {
    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > 2048) req.destroy();
    });

    req.on("end", async () => {
      res.setHeader("Content-Type", "application/json; charset=utf-8");

      if (!BOT_TOKEN || !CHAT_ID) {
        res.writeHead(500);
        return res.end(JSON.stringify({ error: "Сервер не настроен: добавьте BOT_TOKEN и CHAT_ID." }));
      }

      let data;
      try {
        data = JSON.parse(body || "{}");
      } catch {
        res.writeHead(400);
        return res.end(JSON.stringify({ error: "Некорректный запрос." }));
      }

      const code = typeof data.code === "string" ? data.code.trim() : "";

      // Принимаем только явно демонстрационные значения, а не реальные API-ключи.
      if (!/^DEMO-[A-Z0-9-]{4,32}$/i.test(code)) {
        res.writeHead(400);
        return res.end(JSON.stringify({
          error: "Для демонстрации используйте тестовый код формата DEMO-1234. Настоящие API-ключи не принимаются."
        }));
      }

      try {
        const telegramResponse = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: CHAT_ID,
            text: `Демонстрационная проверка NFT\nТестовый код: ${code}`
          })
        });

        const result = await telegramResponse.json();
        if (!telegramResponse.ok || !result.ok) throw new Error("Telegram API error");

        res.writeHead(200);
        res.end(JSON.stringify({ ok: true, message: "Тестовое уведомление отправлено." }));
      } catch {
        res.writeHead(502);
        res.end(JSON.stringify({ error: "Не удалось отправить уведомление в Telegram. Проверьте настройки бота." }));
      }
    });
    return;
  }

  const requestedPath = req.url === "/" ? "index.html" : req.url.replace(/^\/+/, "");
  const filePath = path.join(PUBLIC_DIR, path.normalize(requestedPath));

  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404);
      return res.end("Not found");
    }
    const ext = path.extname(filePath);
    const type = ext === ".css" ? "text/css" : ext === ".js" ? "text/javascript" : "text/html";
    res.writeHead(200, { "Content-Type": `${type}; charset=utf-8` });
    res.end(content);
  });
});

server.listen(PORT, () => {
  console.log(`Demo site listening on port ${PORT}`);
});